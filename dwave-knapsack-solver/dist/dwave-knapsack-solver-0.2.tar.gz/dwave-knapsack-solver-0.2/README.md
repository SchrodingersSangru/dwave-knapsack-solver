# dwave-knapsack-solver is now dwave-knapsack-solver

This package has been renamed. Use `pip install dwave-knapsack-solver` instead.

New package: https://pypi.org/project/dwave-knapsack-solver/
